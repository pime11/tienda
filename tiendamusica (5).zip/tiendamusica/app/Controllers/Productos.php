<?php

namespace App\Controllers;

use App\Models\ProductoModel;
use App\Models\CategoriaModel;

class Productos extends BaseController
{
    protected $productoModel;
    protected $categoriaModel;

    public function __construct()
    {
        $this->productoModel = new ProductoModel();
        $this->categoriaModel = new CategoriaModel();
    }

    public function index()
    {
        $data = [
            'productos' => $this->productoModel->getProductosConCategoria(),
            'categorias' => $this->categoriaModel->findAll(),
        ];

        return view('productos/index', $data);
    }

    public function porCategoria($categoria_id)
    {
        $data = [
            'productos' => $this->productoModel->select('productos.*, categorias.nombre as categoria_nombre')
                                             ->join('categorias', 'categorias.id = productos.categoria_id')
                                             ->where('productos.categoria_id', $categoria_id)
                                             ->findAll(),
            'categoria' => $this->categoriaModel->find($categoria_id),
            'categorias' => $this->categoriaModel->findAll(),
        ];

        return view('productos/por_categoria', $data);
    }

    public function detalle($id)
    {
        $producto = $this->productoModel->find($id);

        if (!$producto) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('El producto no existe');
        }

        $data = [
            'producto' => $producto,
            'categoria' => $this->categoriaModel->find($producto['categoria_id']),
        ];

        return view('productos/detalle', $data);
    }
}