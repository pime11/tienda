<?php

namespace App\Controllers;

use App\Models\CategoriaModel;
use App\Models\ProductoModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Categorias extends BaseController
{
    protected $categoriaModel;
    protected $productoModel;

    public function __construct()
    {
        $this->categoriaModel = new CategoriaModel();
        $this->productoModel = new ProductoModel();
    }

    public function index()
    {
        $categorias = $this->categoriaModel->select('categorias.*, COUNT(productos.id) as total_productos')
                                          ->join('productos', 'productos.categoria_id = categorias.id', 'left')
                                          ->groupBy('categorias.id')
                                          ->findAll();

        $data = [
            'categorias' => $categorias
        ];

        return view('categorias/index', $data);
    }

    public function crear()
    {
        helper(['form', 'url']);

        if ($this->request->getMethod() === 'post') {
            $rules = [
                'nombre' => 'required|min_length[3]|max_length[100]',
                'imagen' => [
                    'uploaded[imagen]',
                    'mime_in[imagen,image/jpg,image/jpeg,image/png]',
                    'max_size[imagen,1024]',
                ],
                'descripcion' => 'permit_empty|max_length[500]'
            ];

            if ($this->validate($rules)) {
                $file = $this->request->getFile('imagen');
                
                if ($file->isValid() && !$file->hasMoved()) {
                    $newName = $file->getRandomName();
                    $file->move(WRITEPATH.'uploads', $newName);

                    $this->categoriaModel->save([
                        'nombre' => $this->request->getPost('nombre'),
                        'descripcion' => $this->request->getPost('descripcion'),
                        'imagen' => $newName
                    ]);

                    return redirect()->to('/categorias')->with('success', 'Categoría creada exitosamente');
                }
            } else {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
        }

        return view('categorias/crear');
    }

    public function editar($id)
    {
        helper(['form', 'url']);

        $categoria = $this->categoriaModel->find($id);

        if (!$categoria) {
            throw new PageNotFoundException('La categoría no existe');
        }

        if ($this->request->getMethod() === 'post') {
            $rules = [
                'nombre' => 'required|min_length[3]|max_length[100]',
                'imagen' => [
                    'mime_in[imagen,image/jpg,image/jpeg,image/png]',
                    'max_size[imagen,1024]',
                ],
                'descripcion' => 'permit_empty|max_length[500]'
            ];

            if ($this->validate($rules)) {
                $data = [
                    'id' => $id,
                    'nombre' => $this->request->getPost('nombre'),
                    'descripcion' => $this->request->getPost('descripcion')
                ];

                $file = $this->request->getFile('imagen');
                
                if ($file->isValid() && !$file->hasMoved()) {
                    $newName = $file->getRandomName();
                    $file->move(WRITEPATH.'uploads', $newName);
                    $data['imagen'] = $newName;
                    
                    // Eliminar imagen anterior si existe
                    if (!empty($categoria['imagen']) && file_exists(WRITEPATH.'uploads/'.$categoria['imagen'])) {
                        unlink(WRITEPATH.'uploads/'.$categoria['imagen']);
                    }
                }

                $this->categoriaModel->save($data);
                return redirect()->to('/categorias')->with('success', 'Categoría actualizada exitosamente');
            } else {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
        }

        return view('categorias/editar', ['categoria' => $categoria]);
    }

    public function eliminar($id)
    {
        $categoria = $this->categoriaModel->find($id);

        if (!$categoria) {
            throw new PageNotFoundException('La categoría no existe');
        }

        // Eliminar imagen asociada si existe
        if (!empty($categoria['imagen']) && file_exists(WRITEPATH.'uploads/'.$categoria['imagen'])) {
            unlink(WRITEPATH.'uploads/'.$categoria['imagen']);
        }

        $this->categoriaModel->delete($id);
        return redirect()->to('/categorias')->with('success', 'Categoría eliminada exitosamente');
    }

    public function getProductosPorCategoria($categoria_id)
    {
        return $this->productoModel->where('categoria_id', $categoria_id)->findAll();
    }
}