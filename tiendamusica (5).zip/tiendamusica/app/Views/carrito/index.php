<?= $this->include('templates/header') ?>

<div class="container my-4">
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <h1>Tu Carrito de Compras</h1>
    
    <?php if (empty($items)): ?>
        <div class="alert alert-info">
            Tu carrito está vacío. <a href="<?= base_url('productos') ?>">Explora nuestros álbumes</a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Álbum</th>
                        <th>Precio Unitario</th>
                        <th>Cantidad</th>
                        <th>Subtotal</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="<?= base_url($item['imagen']) ?>" 
                                     alt="<?= esc($item['nombre']) ?>" 
                                     style="width: 50px; height: 50px; object-fit: cover;" 
                                     class="me-3">
                                <span><?= esc($item['nombre']) ?></span>
                            </div>
                        </td>
                        <td>$<?= number_format($item['precio'], 2) ?></td>
                        <td>
                            <form action="<?= base_url('carrito/actualizar/' . $item['id']) ?>" 
                                  method="post" 
                                  class="d-flex gap-2">
                                <input type="number" 
                                       name="cantidad" 
                                       value="<?= $item['cantidad'] ?>" 
                                       min="1" 
                                       class="form-control" 
                                       style="width: 70px;">
                                <button type="submit" 
                                        class="btn btn-sm btn-outline-primary update-cart">
                                    <i class="bi bi-arrow-clockwise"></i>
                                </button>
                            </form>
                        </td>
                        <td>$<?= number_format($item['precio'] * $item['cantidad'], 2) ?></td>
                        <td>
                            <a href="<?= base_url('carrito/eliminar/' . $item['id']) ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('¿Eliminar este artículo?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" class="text-end"><strong>Total:</strong></td>
                        <td colspan="2"><strong>$<?= number_format($total, 2) ?></strong></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        
        <div class="d-flex justify-content-between mt-4">
            <a href="<?= base_url('productos') ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Seguir Comprando
            </a>
            <form action="<?= base_url('carrito/procesar-pago') ?>" method="post">
                <button type="submit" class="btn btn-success">
                    Proceder al Pago <i class="bi bi-arrow-right"></i>
                </button>
            </form>
        </div>
    <?php endif; ?>
</div>

<?= $this->include('templates/footer') ?>