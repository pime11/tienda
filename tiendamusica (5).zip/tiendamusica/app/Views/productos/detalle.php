<?= $this->include('templates/header') ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-6">
                <img src="<?= esc($producto['imagen']) ?>" class="img-fluid rounded" alt="<?= esc($producto['nombre']) ?>">
            </div>
            <div class="col-md-6">
                <h1><?= esc($producto['nombre']) ?></h1>
                <h3 class="text-muted"><?= esc($producto['artista']) ?></h3>
                <p class="text-muted">Categoría: <?= esc($categoria['nombre']) ?></p>
                
                <div class="my-4">
                    <h2 class="text-primary">$<?= number_format($producto['precio'], 2) ?></h2>
                    <?php if ($producto['stock'] > 0): ?>
                        <span class="badge bg-success">Disponible</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Agotado</span>
                    <?php endif; ?>
                </div>
                
                <div class="mb-4">
                    <h4>Descripción</h4>
                    <p><?= esc($producto['descripcion']) ?></p>
                </div>
                
                <div class="d-flex gap-2">
                    <form action="<?= base_url('carrito/agregar/' . $producto['id']) ?>" method="post">
                        <input type="hidden" name="cantidad" value="1">
                        <button type="submit" class="btn btn-primary btn-lg" <?= $producto['stock'] <= 0 ? 'disabled' : '' ?>>
                            Añadir al Carrito
                        </button>
                    </form>
                    <a href="<?= base_url('productos') ?>" class="btn btn-outline-secondary btn-lg">Volver</a>
                </div>
            </div>
        </div>
    </div>

<?= $this->include('templates/footer') ?>