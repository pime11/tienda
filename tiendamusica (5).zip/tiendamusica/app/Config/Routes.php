<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

$routes->get('/', 'Home::index');
$routes->get('/productos', 'Productos::index');
$routes->get('/productos/categoria/(:num)', 'Productos::porCategoria/$1');
$routes->get('/productos/(:num)', 'Productos::detalle/$1');

$routes->group('categorias', function ($routes) {
    $routes->get('/', 'Categorias::index');
    $routes->get('crear', 'Categorias::crear');
    $routes->post('crear', 'Categorias::crear');
    $routes->get('editar/(:num)', 'Categorias::editar/$1');
    $routes->post('editar/(:num)', 'Categorias::editar/$1');
    $routes->get('eliminar/(:num)', 'Categorias::eliminar/$1');
});

$routes->group('carrito', function ($routes) {
    $routes->get('/', 'Carrito::index');
    $routes->get('agregar/(:num)', 'Carrito::agregar/$1');
    $routes->post('actualizar/(:num)', 'Carrito::actualizar/$1');
    $routes->get('eliminar/(:num)', 'Carrito::eliminar/$1');
    $routes->post('procesar-pago', 'Carrito::procesarPago'); // Nueva ruta
});