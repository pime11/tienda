<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddImageAndDescriptionToCategorias extends Migration
{
    public function up()
    {
        $this->forge->addColumn('categorias', [
            'imagen' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true,
                'after' => 'nombre'
            ],
            'descripcion' => [
                'type' => 'TEXT',
                'null' => true,
                'after' => 'imagen'
            ]
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('categorias', 'imagen');
        $this->forge->dropColumn('categorias', 'descripcion');
    }
}