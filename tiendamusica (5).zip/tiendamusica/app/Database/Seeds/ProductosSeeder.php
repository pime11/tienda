<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ProductosSeeder extends Seeder
{
    public function run()
    {
        // Deshabilitar verificación de claves foráneas
        $this->db->query('SET FOREIGN_KEY_CHECKS=0');
        
        // Vaciar tablas en orden correcto
        $this->db->table('carrito')->truncate();
        $this->db->table('productos')->truncate();
        
        // Habilitar verificación de claves foráneas
        $this->db->query('SET FOREIGN_KEY_CHECKS=1');

        $data = [
            [
                'categoria_id' => 1,
                'nombre' => 'The Dark Side of the Moon',
                'artista' => 'Pink Floyd',
                'descripcion' => 'Álbum clásico de rock progresivo',
                'precio' => 24.99,
                'imagen' => 'img/pinkfloyd.jpg',
                'stock' => 50
            ],
            [
                'categoria_id' => 2,
                'nombre' => 'Thriller',
                'artista' => 'Michael Jackson',
                'descripcion' => 'El álbum más vendido de todos los tiempos',
                'precio' => 19.99,
                'imagen' => 'img/michaeljackson.jpeg',
                'stock' => 30
            ],
            [
                'categoria_id' => 3,
                'nombre' => 'Kind of Blue',
                'artista' => 'Miles Davis',
                'descripcion' => 'Obra maestra del jazz modal',
                'precio' => 22.50,
                'imagen' => 'img/milesdavis.jpeg',
                'stock' => 20
            ],
            [
                'categoria_id' => 1,
                'nombre' => 'Back in Black',
                'artista' => 'AC/DC',
                'descripcion' => 'Clásico del hard rock',
                'precio' => 18.75,
                'imagen' => 'img/acdc.jpg',
                'stock' => 40
            ],
            [
                'categoria_id' => 4,
                'nombre' => 'Symphony No. 9',
                'artista' => 'Ludwig van Beethoven',
                'descripcion' => 'Incluye la famosa "Oda a la Alegría"',
                'precio' => 15.99,
                'imagen' => 'img/beethoven.jpg',
                'stock' => 25
            ],
            [
                'categoria_id' => 6, // J-Pop
                'nombre' => 'Drama',
                'artista' => 'Atarashii Gakko',
                'descripcion' => 'Canción rítmica de vanguardia',
                'precio' => 35.99,
                'imagen' => 'img/atarashi.jpeg',
                'stock' => 23
            ],
            [
                'categoria_id' => 7, // J-Rock
                'nombre' => 'Megitsune',
                'artista' => 'Babymetal',
                'descripcion' => 'Fusión única de metal y pop',
                'precio' => 55.23,
                'imagen' => 'img/babymetal.jpeg',
                'stock' => 40
            ],
            [
                'categoria_id' => 7, // J-Rock
                'nombre' => 'お先に失礼します。',
                'artista' => 'Hanabie',
                'descripcion' => 'Combinación de metalcore y elementos kawaii',
                'precio' => 60.12,
                'imagen' => 'img/hanabie.jpeg',
                'stock' => 26
            ],
            [
                'categoria_id' => 6, // J-Pop
                'nombre' => 'Odo',
                'artista' => 'Ado',
                'descripcion' => 'J-Pop moderno con influencias urbanas',
                'precio' => 55.76,
                'imagen' => 'img/ado.jpg',
                'stock' => 33
            ]
        ];

        $this->db->table('productos')->insertBatch($data);
    }
}